import React from 'react'
export default function App(){
 return <div style={{padding:'40px',fontFamily:'Arial'}}>
 <h1>Tempel kode App.jsx lengkap kamu di sini</h1>
 <p>ZIP ini sudah siap Vite. Ganti isi file src/App.jsx dengan kode yang kamu kirim.</p>
 </div>
}
